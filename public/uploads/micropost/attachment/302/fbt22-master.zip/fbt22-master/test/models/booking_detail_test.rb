require "test_helper"

class BookingDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
