module UsersHelper
  def full_name
    "#{firstname} #{lastname}"
  end
end
