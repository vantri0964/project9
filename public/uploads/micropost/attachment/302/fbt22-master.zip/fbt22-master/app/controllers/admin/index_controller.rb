class Admin::IndexController < ApplicationController
  def home; end
end
